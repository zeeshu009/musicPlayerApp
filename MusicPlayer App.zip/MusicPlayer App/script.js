let progress = document.getElementById("progess");
let songStatus = document.getElementById("song");
let cntrls = document.getElementById("cntrl");
songStatus.onloadedmetadata = function()
{
    progress.max = songStatus.duration;
    progress.value = songStatus.currentTime;
}
cntrls.addEventListener('click',()=>{
    if(cntrls.classList.contains("fa-pause"))
    {
       songStatus.pause();
       cntrls.classList.remove("fa-pause");
       cntrls.classList.add("fa-play");
    }
    else
    {
        songStatus.play();
        cntrls.classList.add("fa-pause");
        cntrls.classList.remove("fa-play");
    }
})
if(songStatus.play())
{
    setInterval(()=>{
        progress.value = songStatus.currentTime;
    },500);
}

progress.onchange = function()
{
    songStatus.play();
    songStatus.currentTime = progress.value;
    cntrls.classList.add("fa-pause");
    cntrls.classList.remove("fa-play");
}